
import React from 'react';

const LoadingScreen: React.FC = () => {
  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#011612]">
      <div className="relative w-24 h-24 mb-8">
        <div className="absolute inset-0 border-4 border-[#d4af37]/20 rounded-full"></div>
        <div className="absolute inset-0 border-4 border-[#d4af37] border-t-transparent rounded-full animate-spin"></div>
        <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-1 h-1 bg-[#d4af37] rounded-full animate-ping"></div>
        </div>
      </div>
      
      <h2 className="text-[#d4af37] text-2xl font-light tracking-[0.5em] animate-pulse">
        Winston
      </h2>
      <p className="text-[#d4af37]/50 text-[10px] uppercase mt-4 tracking-[0.2em]">
        Preparing the signature experience...
      </p>

      <div className="absolute bottom-12 text-[#d4af37]/30 text-[8px] uppercase tracking-widest">
        Luxury Defined by Light
      </div>
    </div>
  );
};

export default LoadingScreen;
