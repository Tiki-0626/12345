
import React, { useMemo, useRef, useEffect } from 'react';
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';

interface ChristmasTreeProps {
  isAssembled: boolean;
}

// Enhanced Foliage Shader with Edge Highlights and Breathing jitter
const FoliageShader = {
  vertexShader: `
    uniform float uTime;
    uniform float uMorph;
    attribute vec3 aScatterPos;
    attribute vec3 aTreePos;
    attribute float aSize;
    attribute float aPhase;
    varying float vGlow;
    varying vec3 vColor;
    varying float vAlpha;

    void main() {
      // Morph between scattered and tree positions
      vec3 targetPos = mix(aScatterPos, aTreePos, uMorph);
      
      // Jitter/Breathing: More intense when scattered
      float jitterIntensity = mix(0.15, 0.05, uMorph);
      targetPos.x += sin(uTime * 2.0 + aPhase) * jitterIntensity;
      targetPos.y += cos(uTime * 1.5 + aPhase) * jitterIntensity;
      targetPos.z += sin(uTime * 1.8 + aPhase) * jitterIntensity;
      
      vec4 mvPosition = modelViewMatrix * vec4(targetPos, 1.0);
      
      // Perspective size attenuation
      gl_PointSize = aSize * (25.0 / -mvPosition.z);
      gl_Position = projectionMatrix * mvPosition;
      
      // Edge glow and color variation
      vGlow = 0.5 + 0.5 * sin(uTime * 1.2 + aPhase * 2.0);
      
      // Deep Emerald base with occasional Gold highlights
      vec3 emerald = vec3(0.004, 0.2, 0.12); // #013220
      vec3 gold = vec3(0.83, 0.68, 0.21);    // #D4AF37
      vColor = mix(emerald, gold, step(0.92, fract(aPhase * 7.0)));
      vAlpha = mix(0.4, 0.8, vGlow);
    }
  `,
  fragmentShader: `
    varying float vGlow;
    varying vec3 vColor;
    varying float vAlpha;
    void main() {
      float dist = distance(gl_PointCoord, vec2(0.5));
      if (dist > 0.5) discard;
      
      // Hard center with soft glowing edge
      float strength = 1.0 - (dist * 2.0);
      float glowEffect = pow(strength, 1.5) * (0.8 + vGlow * 0.4);
      
      gl_FragColor = vec4(vColor, vAlpha * glowEffect);
    }
  `
};

const ChristmasTree: React.FC<ChristmasTreeProps> = ({ isAssembled }) => {
  const foliageRef = useRef<THREE.Points>(null);
  const ornamentRef = useRef<THREE.InstancedMesh>(null);
  const giftRef = useRef<THREE.InstancedMesh>(null);
  const tinyStarsRef = useRef<THREE.InstancedMesh>(null);
  const starRef = useRef<THREE.Mesh>(null);
  const trunkRef = useRef<THREE.Mesh>(null);

  const FOLIAGE_COUNT = 5000;
  const ORNAMENT_COUNT = 100;
  const GIFT_COUNT = 15;
  const TINY_STAR_COUNT = 250;

  // Weights for drift physics
  const WEIGHTS = {
    GIFT: 0.15,      // Heavy: Barely moves
    ORNAMENT: 0.5,   // Light: Moderate drift
    TINY_STAR: 1.5,  // Ultra-light: High flutter
  };

  // 1. Foliage Data
  const foliageData = useMemo(() => {
    const scatterPos = new Float32Array(FOLIAGE_COUNT * 3);
    const treePos = new Float32Array(FOLIAGE_COUNT * 3);
    const sizes = new Float32Array(FOLIAGE_COUNT);
    const phases = new Float32Array(FOLIAGE_COUNT);

    for (let i = 0; i < FOLIAGE_COUNT; i++) {
      // Scatter sphere
      const radius = 12 + Math.random() * 6;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      scatterPos[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
      scatterPos[i * 3 + 1] = radius * Math.sin(phi) * Math.sin(theta) + 4;
      scatterPos[i * 3 + 2] = radius * Math.cos(phi);

      // Conical Tree
      const t = Math.pow(Math.random(), 1.2); // Denser at bottom
      const height = 8;
      const y = t * height;
      const r = (1.05 - t) * 3.5;
      const angle = Math.random() * Math.PI * 2;
      treePos[i * 3] = Math.cos(angle) * r;
      treePos[i * 3 + 1] = y;
      treePos[i * 3 + 2] = Math.sin(angle) * r;

      sizes[i] = 1.5 + Math.random() * 4.0;
      phases[i] = Math.random() * Math.PI * 2;
    }
    return { scatterPos, treePos, sizes, phases };
  }, []);

  // 2. Ornament Data
  const ornamentData = useMemo(() => {
    const data = [];
    for (let i = 0; i < ORNAMENT_COUNT; i++) {
      const sRadius = 9 + Math.random() * 5;
      const sTheta = Math.random() * Math.PI * 2;
      const sPhi = Math.acos(2 * Math.random() - 1);
      const scatterPos = new THREE.Vector3(
        sRadius * Math.sin(sPhi) * Math.cos(sTheta),
        sRadius * Math.sin(sPhi) * Math.sin(sTheta) + 4,
        sRadius * Math.cos(sPhi)
      );

      const t = Math.random();
      const tY = t * 7.5;
      const tR = (1 - t) * 3.2;
      const tA = Math.random() * Math.PI * 2;
      const treePos = new THREE.Vector3(Math.cos(tA) * tR, tY, Math.sin(tA) * tR);

      data.push({ scatterPos, treePos, phase: Math.random() * 10, color: i % 3 === 0 ? '#d4af37' : '#ffffff' });
    }
    return data;
  }, []);

  // 3. Gift Data (Heavy)
  const giftData = useMemo(() => {
    const data = [];
    for (let i = 0; i < GIFT_COUNT; i++) {
      const scatterPos = new THREE.Vector3((Math.random() - 0.5) * 20, Math.random() * 10, (Math.random() - 0.5) * 20);
      const angle = (i / GIFT_COUNT) * Math.PI * 2;
      const radius = 3 + Math.random() * 2;
      const treePos = new THREE.Vector3(Math.cos(angle) * radius, 0.4, Math.sin(angle) * radius);
      data.push({ scatterPos, treePos, phase: Math.random() * 10 });
    }
    return data;
  }, []);

  // 4. Tiny Stars (Ultra-light)
  const tinyStarData = useMemo(() => {
    const data = [];
    for (let i = 0; i < TINY_STAR_COUNT; i++) {
      const radius = 15 + Math.random() * 10;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      const scatterPos = new THREE.Vector3(
        radius * Math.sin(phi) * Math.cos(theta),
        radius * Math.sin(phi) * Math.sin(theta) + 5,
        radius * Math.cos(phi)
      );

      const t = Math.random();
      const tY = t * 8;
      const tR = (1 - t) * 3.8;
      const tA = Math.random() * Math.PI * 2;
      const treePos = new THREE.Vector3(Math.cos(tA) * tR, tY, Math.sin(tA) * tR);
      data.push({ scatterPos, treePos, phase: Math.random() * 20 });
    }
    return data;
  }, []);

  const dummy = useMemo(() => new THREE.Object3D(), []);
  const morphValue = useRef(0);

  useFrame((state) => {
    const time = state.clock.getElapsedTime();
    const targetMorph = isAssembled ? 1 : 0;
    morphValue.current = THREE.MathUtils.lerp(morphValue.current, targetMorph, 0.035);

    // Update Foliage Shader
    if (foliageRef.current) {
      const mat = foliageRef.current.material as THREE.ShaderMaterial;
      mat.uniforms.uTime.value = time;
      mat.uniforms.uMorph.value = morphValue.current;
    }

    // Update Gifts (Heavy)
    if (giftRef.current) {
      giftData.forEach((p, i) => {
        const drift = Math.sin(time * 0.3 + p.phase) * WEIGHTS.GIFT * (1.0 - morphValue.current);
        dummy.position.copy(p.scatterPos).lerp(p.treePos, morphValue.current);
        dummy.position.y += drift;
        dummy.rotation.set(0, time * 0.1, 0);
        dummy.scale.setScalar(0.45);
        dummy.updateMatrix();
        giftRef.current!.setMatrixAt(i, dummy.matrix);
      });
      giftRef.current.instanceMatrix.needsUpdate = true;
    }

    // Update Ornaments (Light)
    if (ornamentRef.current) {
      ornamentData.forEach((p, i) => {
        const drift = Math.sin(time + p.phase) * WEIGHTS.ORNAMENT * (1.0 - morphValue.current);
        dummy.position.copy(p.scatterPos).lerp(p.treePos, morphValue.current);
        dummy.position.y += drift;
        dummy.position.x += Math.cos(time + p.phase) * 0.1 * (1.0 - morphValue.current);
        dummy.scale.setScalar(0.12 + Math.sin(time * 2.0 + p.phase) * 0.01);
        dummy.updateMatrix();
        ornamentRef.current!.setMatrixAt(i, dummy.matrix);
      });
      ornamentRef.current.instanceMatrix.needsUpdate = true;
    }

    // Update Tiny Stars (Ultra-light)
    if (tinyStarsRef.current) {
      tinyStarData.forEach((p, i) => {
        const flutter = Math.sin(time * 3.0 + p.phase) * WEIGHTS.TINY_STAR * (1.0 - morphValue.current);
        dummy.position.copy(p.scatterPos).lerp(p.treePos, morphValue.current);
        dummy.position.y += flutter;
        dummy.position.x += Math.sin(time * 2.0 + p.phase) * 0.3 * (1.0 - morphValue.current);
        dummy.scale.setScalar(0.04 * (0.8 + Math.sin(time * 5.0 + p.phase) * 0.5));
        dummy.updateMatrix();
        tinyStarsRef.current!.setMatrixAt(i, dummy.matrix);
      });
      tinyStarsRef.current.instanceMatrix.needsUpdate = true;
    }

    // Star & Trunk
    if (starRef.current) {
      starRef.current.position.y = THREE.MathUtils.lerp(15, 8.3, morphValue.current);
      starRef.current.rotation.y += 0.03;
      starRef.current.scale.setScalar(morphValue.current > 0.6 ? 1.0 : 0.1);
    }
    if (trunkRef.current) {
      trunkRef.current.scale.y = THREE.MathUtils.lerp(0.001, 1, morphValue.current);
    }
  });

  return (
    <group>
      {/* Central Trunk */}
      <mesh ref={trunkRef} position={[0, 0.7, 0]}>
        <cylinderGeometry args={[0.3, 0.5, 1.4, 16]} />
        <meshStandardMaterial color="#0a0502" roughness={1} metalness={0} />
      </mesh>

      {/* Foliage Layer */}
      <points ref={foliageRef}>
        <bufferGeometry>
          <bufferAttribute attach="attributes-position" count={FOLIAGE_COUNT} array={new Float32Array(FOLIAGE_COUNT * 3)} itemSize={3} />
          <bufferAttribute attach="attributes-aScatterPos" count={FOLIAGE_COUNT} array={foliageData.scatterPos} itemSize={3} />
          <bufferAttribute attach="attributes-aTreePos" count={FOLIAGE_COUNT} array={foliageData.treePos} itemSize={3} />
          <bufferAttribute attach="attributes-aSize" count={FOLIAGE_COUNT} array={foliageData.sizes} itemSize={1} />
          <bufferAttribute attach="attributes-aPhase" count={FOLIAGE_COUNT} array={foliageData.phases} itemSize={1} />
        </bufferGeometry>
        <shaderMaterial
          transparent
          depthWrite={false}
          blending={THREE.AdditiveBlending}
          vertexShader={FoliageShader.vertexShader}
          fragmentShader={FoliageShader.fragmentShader}
          uniforms={{ uTime: { value: 0 }, uMorph: { value: 0 } }}
        />
      </points>

      {/* Ornaments - Gold & Silver Metallic Spheres */}
      <instancedMesh ref={ornamentRef} args={[undefined, undefined, ORNAMENT_COUNT]}>
        <sphereGeometry args={[1, 24, 24]} />
        <meshStandardMaterial metalness={1} roughness={0.1} envMapIntensity={1.5} />
      </instancedMesh>

      {/* Gifts - Heavy Emerald Boxes */}
      <instancedMesh ref={giftRef} args={[undefined, undefined, GIFT_COUNT]}>
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial color="#004d40" metalness={0.6} roughness={0.4} />
      </instancedMesh>

      {/* Tiny Stars - Ultra-light flickering points */}
      <instancedMesh ref={tinyStarsRef} args={[undefined, undefined, TINY_STAR_COUNT]}>
        <sphereGeometry args={[1, 8, 8]} />
        <meshStandardMaterial color="#fff4d1" emissive="#fff4d1" emissiveIntensity={3} />
      </instancedMesh>

      {/* Signature Top Star */}
      <mesh ref={starRef}>
        <octahedronGeometry args={[0.7, 0]} />
        <meshStandardMaterial color="#fff176" emissive="#fff176" emissiveIntensity={8} metalness={1} />
        <pointLight intensity={15} distance={12} color="#fff176" />
      </mesh>

      {/* Initial colors for Ornaments */}
      {useEffect(() => {
        if (ornamentRef.current) {
          ornamentData.forEach((p, i) => {
            ornamentRef.current!.setColorAt(i, new THREE.Color(p.color));
          });
          ornamentRef.current.instanceColor!.needsUpdate = true;
        }
      }, [ornamentData])}
    </group>
  );
};

export default ChristmasTree;
