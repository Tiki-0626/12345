
import React, { useState } from 'react';
import { generateChristmasWish } from '../services/geminiService';

interface OverlayProps {
  onWishGenerated: (wish: string) => void;
  isAssembled: boolean;
  toggleAssembly: () => void;
}

const Overlay: React.FC<OverlayProps> = ({ onWishGenerated, isAssembled, toggleAssembly }) => {
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [currentWish, setCurrentWish] = useState<string | null>(null);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || loading) return;

    setLoading(true);
    try {
      const result = await generateChristmasWish(input);
      setCurrentWish(result);
      onWishGenerated(result);
    } catch (error) {
      console.error("Error generating wish:", error);
      const fallback = "A golden glow surrounds your heart this season. May your path be illuminated with joy.";
      setCurrentWish(fallback);
      onWishGenerated(fallback);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="absolute inset-0 z-20 flex flex-col items-center justify-between p-8 pointer-events-none">
      {/* Header */}
      <div className="text-center mt-8 animate-fade-in-down">
        <h1 className="text-5xl md:text-7xl font-bold tracking-tighter text-[#d4af37] drop-shadow-[0_2px_15px_rgba(212,175,55,0.5)]">
          Winston
        </h1>
        <p className="text-[#d4af37]/70 uppercase tracking-[0.4em] text-[10px] md:text-xs mt-3">
          Merry Christmas
        </p>
      </div>

      {/* Morph Toggle Button */}
      <div className="absolute top-1/2 right-8 -translate-y-1/2 pointer-events-auto">
        <button 
          onClick={toggleAssembly}
          className="group flex flex-col items-center gap-2"
        >
          <div className={`w-12 h-12 rounded-full border border-[#d4af37]/40 flex items-center justify-center transition-all duration-700 ${isAssembled ? 'bg-[#d4af37] rotate-180' : 'bg-transparent'}`}>
             <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke={isAssembled ? "#011612" : "#d4af37"} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                {isAssembled ? <path d="M12 3v18M3 12h18"/> : <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>}
             </svg>
          </div>
          <span className="text-[10px] text-[#d4af37]/60 uppercase tracking-widest font-bold opacity-0 group-hover:opacity-100 transition-opacity">
            {isAssembled ? 'Scatter' : 'Assemble'}
          </span>
        </button>
      </div>

      {/* Result Display */}
      {currentWish && (
        <div className="max-w-2xl w-full bg-black/50 backdrop-blur-xl border border-[#d4af37]/20 p-10 rounded-3xl pointer-events-auto transform transition-all animate-scale-up shadow-2xl">
           <div className="w-12 h-[1px] bg-[#d4af37]/40 mx-auto mb-8"></div>
          <p className="text-2xl md:text-3xl text-white font-light italic text-center leading-relaxed font-serif">
            {currentWish}
          </p>
           <div className="w-12 h-[1px] bg-[#d4af37]/40 mx-auto mt-8"></div>
          <button 
            onClick={() => setCurrentWish(null)}
            className="mt-10 mx-auto block text-[#d4af37]/60 border-b border-[#d4af37]/20 hover:text-[#d4af37] hover:border-[#d4af37] transition-all text-[10px] uppercase tracking-[0.3em]"
          >
            Create New Signature
          </button>
        </div>
      )}

      {/* Controls */}
      {!currentWish && (
        <div className="w-full max-w-lg pointer-events-auto transition-all mb-12">
          <form onSubmit={handleGenerate} className="flex flex-col gap-6">
            <div className="relative group">
              <input 
                type="text"
                placeholder="Name your wish..."
                value={input}
                onChange={(e) => setInput(e.target.value)}
                className="w-full bg-black/60 border border-[#d4af37]/30 text-[#d4af37] px-8 py-5 rounded-full focus:outline-none focus:ring-1 focus:ring-[#d4af37] backdrop-blur-md placeholder-[#d4af37]/30 text-lg font-light transition-all"
              />
              <button 
                type="submit"
                disabled={loading}
                className={`absolute right-2 top-2 bottom-2 px-10 rounded-full bg-[#d4af37] text-[#011612] font-bold uppercase tracking-widest text-xs hover:scale-105 transition-all active:scale-95 disabled:opacity-50 shadow-[0_0_20px_rgba(212,175,55,0.3)]`}
              >
                {loading ? 'Crafting' : 'Manifest'}
              </button>
            </div>
            <p className="text-center text-[#d4af37]/40 text-[9px] uppercase tracking-[0.4em] px-4">
              AI-Augmented Luxury Bespoke Greetings
            </p>
          </form>
        </div>
      )}

      <style>{`
        @keyframes fade-in-down {
          from { opacity: 0; transform: translateY(-30px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes scale-up {
          from { opacity: 0; transform: scale(0.95) translateY(20px); }
          to { opacity: 1; transform: scale(1) translateY(0); }
        }
        .animate-fade-in-down { animation: fade-in-down 1.2s cubic-bezier(0.23, 1, 0.32, 1) forwards; }
        .animate-scale-up { animation: scale-up 0.8s cubic-bezier(0.23, 1, 0.32, 1) forwards; }
      `}</style>
    </div>
  );
};

export default Overlay;
