
import React, { useEffect } from 'react';
import * as THREE from 'three';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera, Environment, Sparkles, Stars } from '@react-three/drei';
import { Bloom, EffectComposer, Noise, Vignette, ChromaticAberration } from '@react-three/postprocessing';
import ChristmasTree from './ChristmasTree';

interface SceneProps {
  onLoaded: () => void;
  wish: string | null;
  isAssembled: boolean;
}

const Scene: React.FC<SceneProps> = ({ onLoaded, wish, isAssembled }) => {
  useEffect(() => {
    const timer = setTimeout(onLoaded, 3000);
    return () => clearTimeout(timer);
  }, [onLoaded]);

  return (
    <Canvas 
      shadows 
      className="w-full h-full" 
      gl={{ 
        antialias: true, 
        powerPreference: "high-performance",
        alpha: false 
      }}
    >
      <color attach="background" args={['#000a08']} />
      
      <PerspectiveCamera makeDefault position={[0, 4, 20]} fov={35} />
      <OrbitControls 
        enablePan={false} 
        minDistance={10} 
        maxDistance={35} 
        maxPolarAngle={Math.PI / 1.7}
        autoRotate={!isAssembled || !wish}
        autoRotateSpeed={isAssembled ? 0.35 : 1.4}
      />

      <ambientLight intensity={0.6} />
      <spotLight 
        position={[25, 35, 15]} 
        angle={0.2} 
        penumbra={1} 
        intensity={5} 
        castShadow 
        color="#fff4d1"
      />
      <pointLight position={[-15, 8, -10]} intensity={4} color="#004d40" />

      <Environment preset="night" />

      <group position={[0, -3.5, 0]}>
        <ChristmasTree isAssembled={isAssembled} />
        
        <Sparkles 
          count={isAssembled ? 200 : 800} 
          scale={isAssembled ? 10 : 25} 
          size={4} 
          speed={0.4} 
          color="#d4af37" 
          opacity={0.8}
        />
      </group>

      <Stars radius={250} depth={70} count={12000} factor={7} saturation={0} fade speed={1.2} />

      <EffectComposer disableNormalPass>
        <Bloom 
          luminanceThreshold={0.35} 
          mipmapBlur 
          intensity={2.2} 
          radius={0.6} 
        />
        <ChromaticAberration offset={new THREE.Vector2(0.0015, 0.0015)} />
        <Noise opacity={0.05} />
        <Vignette eskil={false} offset={0.25} darkness={1.25} />
      </EffectComposer>
    </Canvas>
  );
};

export default Scene;
