
import { GoogleGenAI } from "@google/genai";

/**
 * Generates a cinematic Christmas wish based on user input.
 * Follows the @google/genai SDK guidelines for Gemini 3 series models.
 */
export const generateChristmasWish = async (input: string): Promise<string> => {
  // Use process.env.API_KEY directly as required by the SDK guidelines.
  // We initialize the client right before usage to ensure we have the most up-to-date key.
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Generate a short, extremely luxurious, and poetic Christmas wish for "${input}". 
      The tone should be sophisticated, cinematic, and focus on themes of gold, emerald, light, and elegance. 
      Keep it under 30 words. No emojis.`,
      config: {
        temperature: 0.9,
        topP: 0.95,
        // Removed maxOutputTokens to prevent response blocking on Gemini 3 models 
        // which require thinkingBudget if maxOutputTokens is specified.
      }
    });

    // Access the .text property directly (not a method).
    return response.text?.trim() || "May your holiday be as luminous as the Winston gold and as deep as the winter emerald.";
  } catch (error) {
    console.error("Gemini service error:", error);
    return "A signature season of brilliance and grace awaits you.";
  }
};
