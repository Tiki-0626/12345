
import React, { useState, Suspense } from 'react';
import Scene from './components/Scene';
import Overlay from './components/Overlay';
import LoadingScreen from './components/LoadingScreen';

const App: React.FC = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [wish, setWish] = useState<string | null>(null);
  const [isAssembled, setIsAssembled] = useState(false);

  return (
    <div className="relative w-full h-screen overflow-hidden bg-[#011612]">
      {isLoading && <LoadingScreen />}
      
      <Suspense fallback={null}>
        <Scene 
          onLoaded={() => setIsLoading(false)} 
          wish={wish} 
          isAssembled={isAssembled} 
        />
      </Suspense>

      <Overlay 
        onWishGenerated={(newWish) => {
          setWish(newWish);
          setIsAssembled(true); // Automatically assemble when a wish is generated
        }} 
        isAssembled={isAssembled}
        toggleAssembly={() => setIsAssembled(!isAssembled)}
      />
      
      {/* Cinematic Vignette */}
      <div className="pointer-events-none absolute inset-0 z-10 shadow-[inset_0_0_150px_rgba(0,0,0,0.8)]" />
    </div>
  );
};

export default App;
